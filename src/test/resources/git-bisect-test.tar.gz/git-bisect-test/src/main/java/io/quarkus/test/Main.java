package io.quarkus.test;

public class Main {
    public static void main(String[] args) {
        System.out.println("D");
    }
}
// Change 1 for feature-1
// Change 1 for feature-2
// Change 2 for feature-2
// Change 1 for bugfix-1
// Change 1 for feature-3
// Change 1 for feature-4
// Change 2 for feature-4
// Change 1 for bugfix-2
// Change 1 for feature-5
// Change 2 for feature-5
// Change 3 for feature-5
// Change 1 for feature-6
// Change 1 for bugfix-3
// Change 1 for feature-7
// Change 2 for feature-7
// Change 1 for feature-8
// Change 1 for feature-9
// Change 1 for feature-10
// Change 2 for feature-10
